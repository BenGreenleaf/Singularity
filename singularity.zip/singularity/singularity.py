
master_data = {
    'coinbasepro': {'BTC/USDT': [0,0], 'ETH/USDT': [0,0]}
}




def updateData(exchange, pair, data):
    